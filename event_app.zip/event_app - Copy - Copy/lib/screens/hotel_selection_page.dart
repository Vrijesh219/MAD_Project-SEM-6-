import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'booking_details_page.dart';
import '../theme/app_theme.dart';

class Hotel {
  final String name;
  final String location;
  final String imageUrl;
  final double rating;
  final int pricePerDay;
  final List<String> amenities;
  final String description;
  final int capacity;
  final bool isAvailable;

  Hotel({
    required this.name,
    required this.location,
    required this.imageUrl,
    required this.rating,
    required this.pricePerDay,
    required this.amenities,
    required this.description,
    required this.capacity,
    required this.isAvailable,
  });
}

class HotelSelectionPage extends StatefulWidget {
  const HotelSelectionPage({Key? key}) : super(key: key);

  @override
  State<HotelSelectionPage> createState() => _HotelSelectionPageState();
}

class _HotelSelectionPageState extends State<HotelSelectionPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  final List<Hotel> allHotels = [
    Hotel(
      name: 'RIVERS CORNER HOTEL',
      location: 'Surat, Gujarat',
      imageUrl: 'assets/images/hotel1.jpg',
      rating: 4.8,
      pricePerDay: 25000,
      amenities: [
        'Parking',
        'WiFi',
        'Restaurant',
        'Bar',
        'Stage',
        'Dance Floor'
      ],
      description:
          'Luxurious venue perfect for weddings and corporate events with riverside views.',
      capacity: 500,
      isAvailable: true,
    ),
    Hotel(
      name: 'ROYAL PALACE',
      location: 'Ahmedabad, Gujarat',
      imageUrl: 'assets/images/hotel2.jpg',
      rating: 4.6,
      pricePerDay: 35000,
      amenities: ['Pool', 'Spa', 'Gym', 'Restaurant', 'Valet', 'Garden'],
      description:
          'Heritage property with modern amenities and royal ambiance.',
      capacity: 800,
      isAvailable: true,
    ),
    Hotel(
      name: 'THE GRAND VENUE',
      location: 'Vadodara, Gujarat',
      imageUrl: 'assets/images/hotel3.jpg',
      rating: 4.7,
      pricePerDay: 30000,
      amenities: [
        'Garden',
        'Valet',
        'Catering',
        'Bar',
        'Stage',
        'Sound System'
      ],
      description:
          'Contemporary venue with state-of-the-art facilities and elegant decor.',
      capacity: 600,
      isAvailable: true,
    ),
    Hotel(
      name: 'EMERALD GARDENS',
      location: 'Surat, Gujarat',
      imageUrl: 'assets/images/hotel4.jpg',
      rating: 4.5,
      pricePerDay: 28000,
      amenities: ['Garden', 'Parking', 'Catering', 'Decoration', 'WiFi'],
      description:
          'Beautiful outdoor venue with lush gardens and modern facilities.',
      capacity: 400,
      isAvailable: true,
    ),
    Hotel(
      name: 'CRYSTAL PALACE',
      location: 'Rajkot, Gujarat',
      imageUrl: 'assets/images/hotel5.jpg',
      rating: 4.9,
      pricePerDay: 40000,
      amenities: ['AC Halls', 'Valet', 'Restaurant', 'Bar', 'Stage', 'Rooms'],
      description:
          'Premium venue with crystal chandeliers and opulent interiors.',
      capacity: 1000,
      isAvailable: false,
    ),
  ];

  List<Hotel> displayedHotels = [];
  String selectedFilter = 'All';
  final TextEditingController searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<String> filters = [
    'All',
    'Rating',
    'Price: Low to High',
    'Price: High to Low',
    'Capacity',
    'Available',
  ];

  @override
  void initState() {
    super.initState();
    displayedHotels = List.from(allHotels);
    searchController.addListener(_onSearchChanged);
    _animationController = AnimationController(
      vsync: this,
      duration: AppTheme.mediumDuration,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    searchController.dispose();
    _scrollController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = searchController.text.toLowerCase();
    setState(() {
      displayedHotels = allHotels.where((hotel) {
        return hotel.name.toLowerCase().contains(query) ||
            hotel.location.toLowerCase().contains(query) ||
            hotel.amenities
                .any((amenity) => amenity.toLowerCase().contains(query));
      }).toList();
      _applyFilter(selectedFilter);
    });
  }

  void _applyFilter(String filter) {
    setState(() {
      selectedFilter = filter;
      switch (filter) {
        case 'Rating':
          displayedHotels.sort((a, b) => b.rating.compareTo(a.rating));
        case 'Price: Low to High':
          displayedHotels
              .sort((a, b) => a.pricePerDay.compareTo(b.pricePerDay));
        case 'Price: High to Low':
          displayedHotels
              .sort((a, b) => b.pricePerDay.compareTo(a.pricePerDay));
        case 'Capacity':
          displayedHotels.sort((a, b) => b.capacity.compareTo(a.capacity));
        case 'Available':
          displayedHotels =
              displayedHotels.where((hotel) => hotel.isAvailable).toList();
        case 'All':
          displayedHotels = List.from(allHotels);
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.scaffoldBackground,
      body: SafeArea(
        child: CustomScrollView(
          controller: _scrollController,
          slivers: [
            SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(32),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Find Perfect',
                      style:
                          AppTheme.headingLarge.copyWith(color: Colors.white),
                    ),
                    Text(
                      'Event Venue',
                      style: AppTheme.headingLarge.copyWith(
                        color: Colors.white,
                        height: 1.1,
                      ),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: searchController,
                      decoration: AppTheme.searchInputDecoration(
                        hintText: 'Search venues, locations, or amenities...',
                        prefixIcon: Icons.search,
                        onClear: searchController.text.isNotEmpty
                            ? () {
                                searchController.clear();
                                _onSearchChanged();
                              }
                            : null,
                      ),
                    ),
                    const SizedBox(height: 16),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: filters.map((filter) {
                          final isSelected = filter == selectedFilter;
                          return GestureDetector(
                            onTap: () => _applyFilter(filter),
                            child: AnimatedContainer(
                              duration: AppTheme.quickDuration,
                              curve: AppTheme.defaultCurve,
                              margin: const EdgeInsets.only(right: 12),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              decoration: AppTheme.chipDecoration(
                                isSelected: isSelected,
                              ),
                              child: Text(
                                filter,
                                style: AppTheme.bodyMedium.copyWith(
                                  color: isSelected
                                      ? Colors.white
                                      : AppTheme.primaryText,
                                  fontWeight: isSelected
                                      ? FontWeight.w600
                                      : FontWeight.normal,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.all(24),
              sliver: displayedHotels.isEmpty
                  ? SliverFillRemaining(
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.search_off,
                              size: 64,
                              color: AppTheme.lightText,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No venues found',
                              style: AppTheme.bodyLarge.copyWith(
                                color: AppTheme.secondaryText,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          final hotel = displayedHotels[index];
                          return AnimatedBuilder(
                            animation: _animationController,
                            builder: (context, child) {
                              final itemAnimation = Tween<double>(
                                begin: 0.0,
                                end: 1.0,
                              ).animate(
                                CurvedAnimation(
                                  parent: _animationController,
                                  curve: Interval(
                                    (index / displayedHotels.length) * 0.5,
                                    ((index + 1) / displayedHotels.length) *
                                        0.5,
                                    curve: AppTheme.defaultCurve,
                                  ),
                                ),
                              );
                              return FadeTransition(
                                opacity: itemAnimation,
                                child: SlideTransition(
                                  position: Tween<Offset>(
                                    begin: const Offset(0, 0.2),
                                    end: Offset.zero,
                                  ).animate(itemAnimation),
                                  child: child,
                                ),
                              );
                            },
                            child: GestureDetector(
                              onTap: () {
                                if (hotel.isAvailable) {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const BookingDetailsPage(),
                                    ),
                                  );
                                }
                              },
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 24),
                                decoration: AppTheme.cardDecoration,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Stack(
                                      children: [
                                        Hero(
                                          tag: 'hotel_${hotel.name}',
                                          child: ClipRRect(
                                            borderRadius:
                                                const BorderRadius.vertical(
                                              top: Radius.circular(24),
                                            ),
                                            child: Image.asset(
                                              hotel.imageUrl,
                                              height: 200,
                                              width: double.infinity,
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (context, error, stackTrace) {
                                                return Container(
                                                  height: 200,
                                                  color: Colors.grey[300],
                                                  child: Icon(
                                                    Icons.image,
                                                    size: 50,
                                                    color: AppTheme.lightText,
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                        if (!hotel.isAvailable)
                                          Container(
                                            height: 200,
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  const BorderRadius.vertical(
                                                top: Radius.circular(24),
                                              ),
                                              gradient: LinearGradient(
                                                begin: Alignment.topCenter,
                                                end: Alignment.bottomCenter,
                                                colors: [
                                                  Colors.black.withOpacity(0.3),
                                                  Colors.black.withOpacity(0.7),
                                                ],
                                              ),
                                            ),
                                            child: Center(
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                  horizontal: 24,
                                                  vertical: 12,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: Colors.black
                                                      .withOpacity(0.8),
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                                child: Text(
                                                  'Not Available',
                                                  style: AppTheme.headingMedium
                                                      .copyWith(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        Positioned(
                                          top: 16,
                                          right: 16,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 6,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.black
                                                      .withOpacity(0.1),
                                                  blurRadius: 8,
                                                  offset: const Offset(0, 2),
                                                ),
                                              ],
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                const Icon(
                                                  Icons.star,
                                                  size: 16,
                                                  color: Colors.amber,
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  hotel.rating.toString(),
                                                  style: AppTheme.bodyMedium
                                                      .copyWith(
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(16),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            hotel.name,
                                            style: AppTheme.headingMedium,
                                          ),
                                          const SizedBox(height: 8),
                                          Row(
                                            children: [
                                              Icon(
                                                Icons.location_on_outlined,
                                                size: 16,
                                                color: AppTheme.lightText,
                                              ),
                                              const SizedBox(width: 4),
                                              Text(
                                                hotel.location,
                                                style: AppTheme.bodyMedium,
                                              ),
                                              const SizedBox(width: 16),
                                              Icon(
                                                Icons.people_outline,
                                                size: 16,
                                                color: AppTheme.lightText,
                                              ),
                                              const SizedBox(width: 4),
                                              Text(
                                                'Up to ${hotel.capacity}',
                                                style: AppTheme.bodyMedium,
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 12),
                                          Text(
                                            hotel.description,
                                            style: AppTheme.bodyMedium,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 16),
                                          Wrap(
                                            spacing: 8,
                                            runSpacing: 8,
                                            children:
                                                hotel.amenities.map((amenity) {
                                              return Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                  horizontal: 12,
                                                  vertical: 6,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: AppTheme
                                                      .scaffoldBackground,
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                ),
                                                child: Text(
                                                  amenity,
                                                  style: AppTheme.bodySmall,
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                          const SizedBox(height: 16),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    '₹${hotel.pricePerDay}',
                                                    style: AppTheme
                                                        .headingMedium
                                                        .copyWith(
                                                      color:
                                                          AppTheme.primaryColor,
                                                    ),
                                                  ),
                                                  Text(
                                                    'per day',
                                                    style: AppTheme.bodySmall,
                                                  ),
                                                ],
                                              ),
                                              ElevatedButton(
                                                onPressed: hotel.isAvailable
                                                    ? () {
                                                        Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                            builder: (context) =>
                                                                const BookingDetailsPage(),
                                                          ),
                                                        );
                                                      }
                                                    : null,
                                                style: hotel.isAvailable
                                                    ? AppTheme.primaryButton
                                                    : AppTheme.primaryButton
                                                        .copyWith(
                                                        backgroundColor:
                                                            MaterialStateProperty
                                                                .all(
                                                          Colors.grey[300],
                                                        ),
                                                      ),
                                                child: Text(
                                                  hotel.isAvailable
                                                      ? 'Book Now'
                                                      : 'Not Available',
                                                  style: AppTheme.bodyLarge
                                                      .copyWith(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                        childCount: displayedHotels.length,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
