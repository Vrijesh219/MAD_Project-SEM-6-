import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'hotel_selection_page.dart';

class EventSelectionPage extends StatelessWidget {
  const EventSelectionPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'What is the',
                    style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    'Event\'s occasion?',
                    style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: GridView.builder(
                  padding: const EdgeInsets.only(bottom: 24),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1.1,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                  ),
                  itemCount: eventTypes.length,
                  itemBuilder: (context, index) {
                    return _buildEventCard(context, eventTypes[index]);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEventCard(BuildContext context, EventType event) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const HotelSelectionPage()),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.withOpacity(0.1), width: 1),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: event.color.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Text(event.icon, style: const TextStyle(fontSize: 32)),
                ),
                const SizedBox(height: 12),
                Text(
                  event.name,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EventType {
  final String name;
  final String icon;
  final Color color;

  const EventType({
    required this.name,
    required this.icon,
    required this.color,
  });
}

final List<EventType> eventTypes = [
  EventType(name: 'Marriage', icon: '👰', color: Colors.red),
  EventType(name: 'Birthday', icon: '🎂', color: Colors.blue),
  EventType(name: 'Engagement', icon: '💍', color: Colors.pink),
  EventType(name: 'Feast', icon: '🍽️', color: Colors.orange),
  EventType(name: 'Festive Parties', icon: '🎉', color: Colors.purple),
  EventType(name: 'Cruise Party', icon: '🚢', color: Colors.cyan),
  EventType(name: 'Anniversary', icon: '💑', color: Colors.deepPurple),
  EventType(name: 'Christmas Party', icon: '🎄', color: Colors.green),
  EventType(name: 'New Year', icon: '🎆', color: Colors.indigo),
];
