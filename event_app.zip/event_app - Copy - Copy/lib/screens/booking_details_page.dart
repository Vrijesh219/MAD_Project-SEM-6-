import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'confirmation_page.dart';
import '../theme/app_theme.dart';

class AdditionalService {
  final String icon;
  final String title;
  final int price;
  final String description;

  const AdditionalService({
    required this.icon,
    required this.title,
    required this.price,
    required this.description,
  });
}

class BookingDetailsPage extends StatefulWidget {
  const BookingDetailsPage({Key? key}) : super(key: key);

  @override
  State<BookingDetailsPage> createState() => _BookingDetailsPageState();
}

class _BookingDetailsPageState extends State<BookingDetailsPage> {
  final TextEditingController _guestsController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTimeOfDay = TimeOfDay.now();
  final Map<String, bool> selectedServices = {};

  final List<AdditionalService> additionalServices = [
    AdditionalService(
      icon: '👥',
      title: 'Extra Staff',
      price: 2500,
      description: 'Additional staff for better service',
    ),
    AdditionalService(
      icon: '🌙',
      title: 'Full Nighter',
      price: 8000,
      description: 'Extended hours till late night',
    ),
    AdditionalService(
      icon: '🎪',
      title: 'Swings',
      price: 3000,
      description: 'Decorative swings for photos',
    ),
    AdditionalService(
      icon: '🎵',
      title: 'DJ Setup',
      price: 5000,
      description: 'Professional DJ with equipment',
    ),
    AdditionalService(
      icon: '🎭',
      title: 'Stage Decor',
      price: 7000,
      description: 'Premium stage decoration',
    ),
    AdditionalService(
      icon: '📸',
      title: 'Photography',
      price: 10000,
      description: 'Professional photo/video coverage',
    ),
  ];

  int get totalBill {
    int total = 25000; // Base price
    for (var service in additionalServices) {
      if (selectedServices[service.title] == true) {
        total += service.price;
      }
    }
    return total;
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2025, 12, 31),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppTheme.primaryColor,
              onPrimary: Colors.white,
              surface: AppTheme.cardBackground,
              onSurface: AppTheme.primaryText,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTimeOfDay,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: AppTheme.primaryColor,
              onPrimary: Colors.white,
              surface: AppTheme.cardBackground,
              onSurface: AppTheme.primaryText,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedTimeOfDay) {
      setState(() {
        selectedTimeOfDay = picked;
      });
    }
  }

  @override
  void dispose() {
    _guestsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.scaffoldBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: const BorderRadius.vertical(
                    bottom: Radius.circular(32),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Select Date, Time',
                      style:
                          AppTheme.headingLarge.copyWith(color: Colors.white),
                    ),
                    Text(
                      'and Services',
                      style: AppTheme.headingLarge.copyWith(
                        color: Colors.white,
                        height: 1.1,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Number of Guests',
                      style: AppTheme.bodyLarge,
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _guestsController,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: AppTheme.searchInputDecoration(
                        hintText: 'Enter number of guests',
                        prefixIcon: Icons.people_outline,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Select Date',
                                style: AppTheme.bodyLarge,
                              ),
                              const SizedBox(height: 8),
                              InkWell(
                                onTap: () => _selectDate(context),
                                child: Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: AppTheme.cardDecoration,
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.calendar_today,
                                        color: AppTheme.primaryColor,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        '${selectedDate.day}/${selectedDate.month}/${selectedDate.year}',
                                        style: AppTheme.bodyMedium,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Select Time',
                                style: AppTheme.bodyLarge,
                              ),
                              const SizedBox(height: 8),
                              InkWell(
                                onTap: () => _selectTime(context),
                                child: Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: AppTheme.cardDecoration,
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.access_time,
                                        color: AppTheme.primaryColor,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        selectedTimeOfDay.format(context),
                                        style: AppTheme.bodyMedium,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 32),
                    Text(
                      'Additional Services',
                      style: AppTheme.bodyLarge,
                    ),
                    const SizedBox(height: 16),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 1.1,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                      ),
                      itemCount: additionalServices.length,
                      itemBuilder: (context, index) {
                        final service = additionalServices[index];
                        final isSelected =
                            selectedServices[service.title] ?? false;
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedServices[service.title] = !isSelected;
                            });
                          },
                          child: AnimatedContainer(
                            duration: AppTheme.quickDuration,
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppTheme.primaryColor
                                  : AppTheme.cardBackground,
                              borderRadius: BorderRadius.circular(24),
                              boxShadow: [
                                BoxShadow(
                                  color: isSelected
                                      ? AppTheme.primaryColor.withOpacity(0.3)
                                      : Colors.black.withOpacity(0.05),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Stack(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        service.icon,
                                        style: const TextStyle(fontSize: 32),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        service.title,
                                        style: AppTheme.bodyLarge.copyWith(
                                          color: isSelected
                                              ? Colors.white
                                              : AppTheme.primaryText,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        service.description,
                                        style: AppTheme.bodySmall.copyWith(
                                          color: isSelected
                                              ? Colors.white.withOpacity(0.8)
                                              : AppTheme.secondaryText,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const Spacer(),
                                      Text(
                                        '₹${service.price}',
                                        style: AppTheme.bodyMedium.copyWith(
                                          color: isSelected
                                              ? Colors.white
                                              : AppTheme.primaryColor,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isSelected)
                                  Positioned(
                                    top: 8,
                                    right: 8,
                                    child: Container(
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: AppTheme.primaryColor
                                                .withOpacity(0.3),
                                            blurRadius: 4,
                                            offset: const Offset(0, 2),
                                          ),
                                        ],
                                      ),
                                      child: Icon(
                                        Icons.check,
                                        size: 16,
                                        color: AppTheme.primaryColor,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: AppTheme.cardDecoration,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Total Amount',
                                style: AppTheme.bodyMedium,
                              ),
                              Text(
                                '₹$totalBill',
                                style: AppTheme.headingMedium.copyWith(
                                  color: AppTheme.primaryColor,
                                ),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: () {
                              if (_guestsController.text.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Please enter number of guests',
                                      style: AppTheme.bodyMedium
                                          .copyWith(color: Colors.white),
                                    ),
                                    backgroundColor: AppTheme.errorColor,
                                  ),
                                );
                                return;
                              }

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ConfirmationPage(
                                    hotelName: 'RIVERS CORNER HOTEL',
                                    eventType: 'Marriage',
                                    selectedServices: selectedServices.entries
                                        .where((e) => e.value)
                                        .map((e) => e.key)
                                        .toList(),
                                    numberOfPeople:
                                        int.parse(_guestsController.text),
                                    selectedDate: selectedDate,
                                    selectedTime:
                                        selectedTimeOfDay.format(context),
                                    extraServices: const ['Full Nighter'],
                                    totalBill: totalBill,
                                  ),
                                ),
                              );
                            },
                            style: AppTheme.primaryButton,
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 32),
                              child: Text(
                                'Proceed',
                                style: AppTheme.bodyLarge.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
