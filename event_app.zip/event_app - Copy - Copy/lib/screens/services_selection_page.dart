import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'booking_details_page.dart';

class Service {
  final String name;
  final String icon;
  bool isSelected;

  Service({required this.name, required this.icon, this.isSelected = false});
}

class ServicesSelectionPage extends StatefulWidget {
  const ServicesSelectionPage({Key? key}) : super(key: key);

  @override
  State<ServicesSelectionPage> createState() => _ServicesSelectionPageState();
}

class _ServicesSelectionPageState extends State<ServicesSelectionPage> {
  final List<Service> services = [
    Service(name: 'Catering and Food', icon: '🍽️'),
    Service(name: 'Flower Decorations', icon: '🌺'),
    Service(name: 'Balloon Decorations', icon: '🎈'),
    Service(name: 'Bar', icon: '🍸'),
    Service(name: 'Accommodation', icon: '🏨'),
    Service(name: 'Entertainment', icon: '🎭'),
    Service(name: 'Photography', icon: '📸'),
    Service(name: 'Theme Decorations', icon: '🎪'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'What are the',
                    style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    'services you require?',
                    style: GoogleFonts.poppins(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: services.length,
                itemBuilder: (context, index) {
                  return _buildServiceCard(services[index]);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const BookingDetailsPage(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2196F3),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  minimumSize: const Size(double.infinity, 56),
                ),
                child: Text(
                  'Continue',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceCard(Service service) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          setState(() {
            service.isSelected = !service.isSelected;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color:
                service.isSelected
                    ? Colors.blue.withOpacity(0.1)
                    : Colors.grey[100],
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: service.isSelected ? Colors.blue : Colors.grey[300]!,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color:
                      service.isSelected
                          ? Colors.blue.withOpacity(0.1)
                          : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(service.icon, style: const TextStyle(fontSize: 24)),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  service.name,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ),
              if (service.isSelected)
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.check, color: Colors.white, size: 16),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
