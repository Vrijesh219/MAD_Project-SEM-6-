import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:hive/hive.dart';
import '../../core/app_constants.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FacebookAuth _facebookAuth = FacebookAuth.instance;

  // Get current user
  User? get currentUser => _auth.currentUser;

  // Stream of auth state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Sign in with Google
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      await _saveUserData(userCredential.user);
      return userCredential;
    } catch (e) {
      print('Error signing in with Google: $e');
      rethrow;
    }
  }

  // Sign in with Facebook
  Future<UserCredential?> signInWithFacebook() async {
    try {
      final LoginResult result = await _facebookAuth.login();
      if (result.status != LoginStatus.success) return null;

      final OAuthCredential credential = FacebookAuthProvider.credential(
        result.accessToken!.token,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      await _saveUserData(userCredential.user);
      return userCredential;
    } catch (e) {
      print('Error signing in with Facebook: $e');
      rethrow;
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      await _googleSignIn.signOut();
      await _facebookAuth.logOut();
      await _auth.signOut();
      await _clearUserData();
    } catch (e) {
      print('Error signing out: $e');
      rethrow;
    }
  }

  // Save user data to local storage
  Future<void> _saveUserData(User? user) async {
    if (user == null) return;

    final box = await Hive.openBox(AppConstants.userBox);
    await box.put(AppConstants.userIdKey, user.uid);
    await box.put('userEmail', user.email);
    await box.put('userName', user.displayName);
    await box.put('userPhoto', user.photoURL);
  }

  // Clear user data from local storage
  Future<void> _clearUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    await box.clear();
  }

  // Get user data from local storage
  Future<Map<String, dynamic>> getUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    return {
      'userId': box.get(AppConstants.userIdKey),
      'email': box.get('userEmail'),
      'name': box.get('userName'),
      'photoUrl': box.get('userPhoto'),
    };
  }
}
