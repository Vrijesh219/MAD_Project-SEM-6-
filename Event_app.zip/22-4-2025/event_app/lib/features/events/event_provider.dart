import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import 'package:provider/provider.dart';
import '../../core/app_constants.dart';
import 'event_model.dart';

class EventProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Event> _events = [];
  bool _isLoading = false;
  String? _error;

  List<Event> get events => _events;
  bool get isLoading => _isLoading;
  String? get error => _error;

  EventProvider() {
    _loadEvents();
  }

  Future<void> _loadEvents() async {
    _isLoading = true;
    notifyListeners();

    try {
      // Load from local storage first
      final box = await Hive.openBox<Event>(AppConstants.eventsBox);
      _events = box.values.toList();

      // Load from Firestore
      final userData = await _getUserData();
      if (userData['userId'] != null) {
        final snapshot = await _firestore
            .collection('events')
            .where('userId', isEqualTo: userData['userId'])
            .get();

        _events =
            snapshot.docs.map((doc) => Event.fromJson(doc.data())).toList();

        // Update local storage
        await box.clear();
        for (var event in _events) {
          await box.put(event.id, event);
        }
      }

      _error = null;
    } catch (e) {
      _error = 'Failed to load events: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addEvent(Event event) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Add to Firestore
      await _firestore.collection('events').doc(event.id).set(event.toJson());

      // Add to local storage
      final box = await Hive.openBox<Event>(AppConstants.eventsBox);
      await box.put(event.id, event);

      _events.add(event);
      _error = null;
    } catch (e) {
      _error = 'Failed to add event: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateEvent(Event event) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Update in Firestore
      await _firestore
          .collection('events')
          .doc(event.id)
          .update(event.toJson());

      // Update in local storage
      final box = await Hive.openBox<Event>(AppConstants.eventsBox);
      await box.put(event.id, event);

      final index = _events.indexWhere((e) => e.id == event.id);
      if (index != -1) {
        _events[index] = event;
      }

      _error = null;
    } catch (e) {
      _error = 'Failed to update event: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> deleteEvent(String eventId) async {
    _isLoading = true;
    notifyListeners();

    try {
      // Delete from Firestore
      await _firestore.collection('events').doc(eventId).delete();

      // Delete from local storage
      final box = await Hive.openBox<Event>(AppConstants.eventsBox);
      await box.delete(eventId);

      _events.removeWhere((event) => event.id == eventId);
      _error = null;
    } catch (e) {
      _error = 'Failed to delete event: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> _getUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    return {
      'userId': box.get(AppConstants.userIdKey),
      'email': box.get('userEmail'),
      'name': box.get('userName'),
      'photoUrl': box.get('userPhoto'),
    };
  }
}
