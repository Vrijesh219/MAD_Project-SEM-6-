import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../core/app_constants.dart';
import 'event_provider.dart';
import 'event_model.dart';
import 'add_event_screen.dart';

class EventDetailScreen extends StatelessWidget {
  const EventDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final event = ModalRoute.of(context)!.settings.arguments as Event;
    final eventProvider = context.read<EventProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Event Details',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              Navigator.pushNamed(
                context,
                AppConstants.addEventRoute,
                arguments: event,
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(
                    'Delete Event',
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  content: Text(
                    'Are you sure you want to delete this event?',
                    style: GoogleFonts.poppins(),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: Text(
                        'Cancel',
                        style: GoogleFonts.poppins(
                          color: AppConstants.textColor,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: Text(
                        'Delete',
                        style: GoogleFonts.poppins(
                          color: AppConstants.errorColor,
                        ),
                      ),
                    ),
                  ],
                ),
              );

              if (confirmed == true) {
                await eventProvider.deleteEvent(event.id);
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Event deleted successfully',
                        style: GoogleFonts.poppins(),
                      ),
                      backgroundColor: AppConstants.successColor,
                    ),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          _getEventIcon(event.category),
                          color: AppConstants.primaryColor,
                          size: 32,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            event.title,
                            style: GoogleFonts.poppins(
                              fontSize: 24,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Description',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: AppConstants.textColor.withOpacity(0.7),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      event.description,
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 24),
                    _buildDetailRow(
                      Icons.location_on,
                      'Location',
                      event.location,
                    ),
                    const SizedBox(height: 16),
                    _buildDetailRow(
                      Icons.calendar_today,
                      'Date',
                      DateFormat('dd MMMM yyyy').format(event.date),
                    ),
                    const SizedBox(height: 16),
                    _buildDetailRow(
                      Icons.category,
                      'Category',
                      event.category,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Event Ideas',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            _buildEventIdeas(event.category),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(
          icon,
          color: AppConstants.primaryColor,
          size: 24,
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: AppConstants.textColor.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildEventIdeas(String category) {
    // This is a placeholder for actual event ideas from an API
    // In a real app, you would fetch these from an external API
    final ideas = _getEventIdeasForCategory(category);

    return Column(
      children: ideas.map((idea) {
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(
                  Icons.lightbulb_outline,
                  color: AppConstants.accentColor,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    idea,
                    style: GoogleFonts.poppins(),
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  List<String> _getEventIdeasForCategory(String category) {
    switch (category.toLowerCase()) {
      case 'birthday party':
        return [
          'Create a photo booth with fun props',
          'Set up a dessert table with a variety of treats',
          'Organize fun games and activities for guests',
        ];
      case 'wedding ceremony':
        return [
          'Plan a beautiful outdoor ceremony',
          'Create a unique guest book alternative',
          'Design a stunning reception entrance',
        ];
      case 'night party':
        return [
          'Set up a dance floor with disco lights',
          'Create a signature cocktail for the event',
          'Hire a DJ or live band for entertainment',
        ];
      case 'corporate event':
        return [
          'Organize team-building activities',
          'Set up networking stations',
          'Create an engaging presentation setup',
        ];
      default:
        return [
          'Create a memorable entrance',
          'Plan engaging activities for guests',
          'Set up a themed decoration',
        ];
    }
  }

  IconData _getEventIcon(String category) {
    switch (category.toLowerCase()) {
      case 'birthday party':
        return Icons.cake;
      case 'wedding ceremony':
        return Icons.favorite;
      case 'night party':
        return Icons.nightlife;
      case 'corporate event':
        return Icons.business;
      default:
        return Icons.event;
    }
  }
}
