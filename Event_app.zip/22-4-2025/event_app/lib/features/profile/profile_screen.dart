import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../core/app_constants.dart';
import '../auth/auth_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Profile',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _getUserData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading profile: ${snapshot.error}',
                style: GoogleFonts.poppins(
                  color: AppConstants.errorColor,
                ),
              ),
            );
          }

          final userData = snapshot.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const SizedBox(height: 24),
                CircleAvatar(
                  radius: 50,
                  backgroundColor: AppConstants.primaryColor.withOpacity(0.1),
                  backgroundImage: userData['photoUrl'] != null
                      ? CachedNetworkImageProvider(userData['photoUrl'])
                      : null,
                  child: userData['photoUrl'] == null
                      ? Text(
                          userData['name']?[0] ?? 'U',
                          style: GoogleFonts.poppins(
                            fontSize: 32,
                            fontWeight: FontWeight.w600,
                            color: AppConstants.primaryColor,
                          ),
                        )
                      : null,
                ),
                const SizedBox(height: 24),
                Text(
                  userData['name'] ?? 'User',
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  userData['email'] ?? '',
                  style: GoogleFonts.poppins(
                    color: AppConstants.textColor.withOpacity(0.7),
                  ),
                ),
                const SizedBox(height: 48),
                _buildInfoCard(
                  'Account Information',
                  [
                    _buildInfoRow('User ID', userData['userId'] ?? 'N/A'),
                    _buildInfoRow('Email', userData['email'] ?? 'N/A'),
                    _buildInfoRow('Name', userData['name'] ?? 'N/A'),
                  ],
                ),
                const SizedBox(height: 24),
                _buildInfoCard(
                  'App Information',
                  [
                    _buildInfoRow('Version', '1.0.0'),
                    _buildInfoRow('Last Updated', 'April 2024'),
                  ],
                ),
                const SizedBox(height: 48),
                ElevatedButton(
                  onPressed: () => _logout(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppConstants.errorColor,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 16,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: Text(
                    'Logout',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.poppins(
                color: AppConstants.textColor.withOpacity(0.7),
              ),
            ),
          ),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Future<Map<String, dynamic>> _getUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    return {
      'userId': box.get(AppConstants.userIdKey),
      'email': box.get('userEmail'),
      'name': box.get('userName'),
      'photoUrl': box.get('userPhoto'),
    };
  }

  Future<void> _logout(BuildContext context) async {
    try {
      final authService = context.read<AuthService>();
      await authService.signOut();
      if (context.mounted) {
        Navigator.pushReplacementNamed(context, AppConstants.loginRoute);
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error logging out: $e',
              style: GoogleFonts.poppins(),
            ),
            backgroundColor: AppConstants.errorColor,
          ),
        );
      }
    }
  }
}
