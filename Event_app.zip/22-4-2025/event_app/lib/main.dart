import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'core/app_constants.dart';
import 'core/firebase_options.dart';
import 'features/auth/auth_service.dart';
import 'features/events/event_provider.dart';
import 'features/auth/login_screen.dart';
import 'features/events/event_list_screen.dart';
import 'features/events/add_event_screen.dart';
import 'features/events/event_detail_screen.dart';
import 'features/profile/profile_screen.dart';
import 'features/events/event_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await Hive.initFlutter();
  Hive.registerAdapter(EventAdapter());
  await Hive.openBox(AppConstants.userBox);
  await Hive.openBox<Event>(AppConstants.eventsBox);
  runApp(const EventEaseApp());
}

class EventEaseApp extends StatelessWidget {
  const EventEaseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => EventProvider()),
      ],
      child: MaterialApp(
        title: 'EventEase',
        theme: AppConstants.lightTheme,
        initialRoute: AppConstants.loginRoute,
        routes: {
          AppConstants.loginRoute: (context) => const LoginScreen(),
          AppConstants.homeRoute: (context) => const EventListScreen(),
          AppConstants.addEventRoute: (context) => const AddEventScreen(),
          AppConstants.eventDetailsRoute: (context) =>
              const EventDetailScreen(),
          AppConstants.profileRoute: (context) => const ProfileScreen(),
        },
      ),
    );
  }
}
