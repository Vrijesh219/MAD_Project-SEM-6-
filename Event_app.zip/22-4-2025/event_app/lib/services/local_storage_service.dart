import 'package:hive/hive.dart';
import '../core/app_constants.dart';
import '../features/events/event_model.dart';

class LocalStorageService {
  Future<void> saveUserData({
    required String userId,
    required String? email,
    required String? name,
    required String? photoUrl,
  }) async {
    final box = await Hive.openBox(AppConstants.userBox);
    await box.put(AppConstants.userIdKey, userId);
    await box.put('userEmail', email);
    await box.put('userName', name);
    await box.put('userPhoto', photoUrl);
  }

  Future<Map<String, dynamic>> getUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    return {
      'userId': box.get(AppConstants.userIdKey),
      'email': box.get('userEmail'),
      'name': box.get('userName'),
      'photoUrl': box.get('userPhoto'),
    };
  }

  Future<void> clearUserData() async {
    final box = await Hive.openBox(AppConstants.userBox);
    await box.clear();
  }

  Future<void> saveEvent(Event event) async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    await box.put(event.id, event);
  }

  Future<void> saveEvents(List<Event> events) async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    await box.clear();
    for (var event in events) {
      await box.put(event.id, event);
    }
  }

  Future<List<Event>> getEvents() async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    return box.values.toList();
  }

  Future<Event?> getEvent(String eventId) async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    return box.get(eventId);
  }

  Future<void> deleteEvent(String eventId) async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    await box.delete(eventId);
  }

  Future<void> clearEvents() async {
    final box = await Hive.openBox<Event>(AppConstants.eventsBox);
    await box.clear();
  }

  Future<void> clearAll() async {
    await clearUserData();
    await clearEvents();
  }
}
