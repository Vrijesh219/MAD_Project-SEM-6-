import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _baseUrl = 'https://api.example.com/v1';

  Future<List<String>> getEventIdeas(String category) async {
    try {
      // This is a mock API call since we don't have a real API
      // In a real app, you would make an actual API call here
      await Future.delayed(const Duration(seconds: 1));

      // Return mock data based on category
      switch (category.toLowerCase()) {
        case 'birthday party':
          return [
            'Set up a themed photo booth with props',
            'Create a candy bar with favorite sweets',
            'Organize interactive party games',
            'Make a DIY birthday banner',
            'Set up a cake decorating station',
          ];
        case 'wedding ceremony':
          return [
            'Create a romantic outdoor ceremony setup',
            'Design a unique guest book experience',
            'Set up a flower wall for photos',
            'Arrange a stunning reception entrance',
            'Plan a memorable first dance moment',
          ];
        case 'night party':
          return [
            'Install dynamic LED lighting',
            'Create a signature cocktail menu',
            'Set up a professional sound system',
            'Design an Instagram-worthy backdrop',
            'Arrange comfortable lounge areas',
          ];
        case 'corporate event':
          return [
            'Plan interactive team building activities',
            'Set up professional networking zones',
            'Create an engaging presentation area',
            'Design branded photo opportunities',
            'Arrange comfortable breakout spaces',
          ];
        default:
          return [
            'Create a welcoming entrance',
            'Plan engaging activities',
            'Design themed decorations',
            'Set up proper lighting',
            'Arrange comfortable seating',
          ];
      }
    } catch (e) {
      throw Exception('Failed to load event ideas: $e');
    }
  }

  Future<List<String>> getEventQuotes(String category) async {
    try {
      // This is a mock API call
      await Future.delayed(const Duration(seconds: 1));

      // Return mock quotes based on category
      switch (category.toLowerCase()) {
        case 'birthday party':
          return [
            'Life is a party, dress like it',
            'Party like it\'s your birthday... because it is!',
            'Make every moment count',
          ];
        case 'wedding ceremony':
          return [
            'Love is in the air',
            'Together is a beautiful place to be',
            'And so the adventure begins',
          ];
        case 'night party':
          return [
            'Life is short, party hard',
            'Dance all night',
            'Good vibes only',
          ];
        case 'corporate event':
          return [
            'Success is built on teamwork',
            'Together we achieve more',
            'Innovation starts here',
          ];
        default:
          return [
            'Create memories that last forever',
            'Every moment matters',
            'Celebrate life',
          ];
      }
    } catch (e) {
      throw Exception('Failed to load event quotes: $e');
    }
  }

  // For future implementation: Real API calls
  Future<List<String>> _fetchFromApi(String endpoint) async {
    try {
      final response = await http.get(Uri.parse('$_baseUrl/$endpoint'));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((item) => item.toString()).toList();
      } else {
        throw Exception('Failed to load data: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to connect to the server: $e');
    }
  }
}
