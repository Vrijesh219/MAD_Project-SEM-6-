import 'package:cloud_firestore/cloud_firestore.dart';
import '../features/events/event_model.dart';

class CloudFirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _eventsCollection = 'events';

  // Create a new event
  Future<void> createEvent(Event event) async {
    try {
      await _firestore
          .collection(_eventsCollection)
          .doc(event.id)
          .set(event.toJson());
    } catch (e) {
      throw Exception('Failed to create event: $e');
    }
  }

  // Get all events for a user
  Future<List<Event>> getEvents(String userId) async {
    try {
      final snapshot = await _firestore
          .collection(_eventsCollection)
          .where('userId', isEqualTo: userId)
          .get();

      return snapshot.docs.map((doc) => Event.fromJson(doc.data())).toList();
    } catch (e) {
      throw Exception('Failed to get events: $e');
    }
  }

  // Get a single event by ID
  Future<Event?> getEvent(String eventId) async {
    try {
      final doc =
          await _firestore.collection(_eventsCollection).doc(eventId).get();

      if (doc.exists) {
        return Event.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get event: $e');
    }
  }

  // Update an existing event
  Future<void> updateEvent(Event event) async {
    try {
      await _firestore
          .collection(_eventsCollection)
          .doc(event.id)
          .update(event.toJson());
    } catch (e) {
      throw Exception('Failed to update event: $e');
    }
  }

  // Delete an event
  Future<void> deleteEvent(String eventId) async {
    try {
      await _firestore.collection(_eventsCollection).doc(eventId).delete();
    } catch (e) {
      throw Exception('Failed to delete event: $e');
    }
  }

  // Get events by category
  Future<List<Event>> getEventsByCategory(
      String userId, String category) async {
    try {
      final snapshot = await _firestore
          .collection(_eventsCollection)
          .where('userId', isEqualTo: userId)
          .where('category', isEqualTo: category)
          .get();

      return snapshot.docs.map((doc) => Event.fromJson(doc.data())).toList();
    } catch (e) {
      throw Exception('Failed to get events by category: $e');
    }
  }

  // Get upcoming events
  Future<List<Event>> getUpcomingEvents(String userId) async {
    try {
      final now = DateTime.now();
      final snapshot = await _firestore
          .collection(_eventsCollection)
          .where('userId', isEqualTo: userId)
          .where('date', isGreaterThanOrEqualTo: now)
          .orderBy('date')
          .get();

      return snapshot.docs.map((doc) => Event.fromJson(doc.data())).toList();
    } catch (e) {
      throw Exception('Failed to get upcoming events: $e');
    }
  }

  // Get past events
  Future<List<Event>> getPastEvents(String userId) async {
    try {
      final now = DateTime.now();
      final snapshot = await _firestore
          .collection(_eventsCollection)
          .where('userId', isEqualTo: userId)
          .where('date', isLessThan: now)
          .orderBy('date', descending: true)
          .get();

      return snapshot.docs.map((doc) => Event.fromJson(doc.data())).toList();
    } catch (e) {
      throw Exception('Failed to get past events: $e');
    }
  }

  // Delete all events for a user
  Future<void> deleteAllEvents(String userId) async {
    try {
      final batch = _firestore.batch();
      final snapshot = await _firestore
          .collection(_eventsCollection)
          .where('userId', isEqualTo: userId)
          .get();

      for (var doc in snapshot.docs) {
        batch.delete(doc.reference);
      }

      await batch.commit();
    } catch (e) {
      throw Exception('Failed to delete all events: $e');
    }
  }
}
