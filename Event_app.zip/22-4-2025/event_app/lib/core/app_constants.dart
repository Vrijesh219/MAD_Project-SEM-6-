import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppConstants {
  // App Colors
  static const Color primaryColor = Color(0xFF6C63FF);
  static const Color secondaryColor = Color(0xFF3F3D56);
  static const Color accentColor = Color(0xFFFF6584);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color textColor = Color(0xFF2D2D2D);
  static const Color errorColor = Color(0xFFE57373);
  static const Color successColor = Color(0xFF81C784);

  // App Theme
  static ThemeData get lightTheme {
    return ThemeData(
      primaryColor: primaryColor,
      colorScheme: ColorScheme.light(
        primary: primaryColor,
        secondary: secondaryColor,
        error: errorColor,
      ),
      scaffoldBackgroundColor: backgroundColor,
      textTheme: GoogleFonts.poppinsTextTheme(),
      appBarTheme: AppBarTheme(
        backgroundColor: primaryColor,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: GoogleFonts.poppins(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }

  // API Constants
  static const String eventsApiBaseUrl = 'https://api.example.com/events';
  static const String quotesApiBaseUrl = 'https://api.example.com/quotes';

  // Storage Keys
  static const String userBox = 'userBox';
  static const String eventsBox = 'eventsBox';
  static const String authTokenKey = 'authToken';
  static const String userIdKey = 'userId';

  // Navigation Routes
  static const String loginRoute = '/login';
  static const String homeRoute = '/';
  static const String addEventRoute = '/add-event';
  static const String eventDetailsRoute = '/event-details';
  static const String profileRoute = '/profile';

  // Event Types
  static const List<String> eventTypes = [
    'Birthday Party',
    'Wedding Ceremony',
    'Night Party',
    'Corporate Event',
    'Other'
  ];
}
