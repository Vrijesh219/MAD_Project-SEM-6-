import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyCz_UdqRZ7xlJ87wprXT9PsIKAtkHC3CUg',
    appId: '1:835195623873:web:5e860b14d582d2f6163740',
    messagingSenderId: '835195623873',
    projectId: 'event-app-58dd0',
    authDomain: 'event-app-58dd0.firebaseapp.com',
    storageBucket: 'event-app-58dd0.firebasestorage.app',
    measurementId: 'G-7YDPSELS2R',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCz_UdqRZ7xlJ87wprXT9PsIKAtkHC3CUg',
    appId: '1:835195623873:android:5e860b14d582d2f6163740',
    messagingSenderId: '835195623873',
    projectId: 'event-app-58dd0',
    storageBucket: 'event-app-58dd0.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCz_UdqRZ7xlJ87wprXT9PsIKAtkHC3CUg',
    appId: '1:835195623873:ios:5e860b14d582d2f6163740',
    messagingSenderId: '835195623873',
    projectId: 'event-app-58dd0',
    storageBucket: 'event-app-58dd0.firebasestorage.app',
    iosClientId: 'YOUR_IOS_CLIENT_ID',
    iosBundleId: 'com.example.eventApp',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCz_UdqRZ7xlJ87wprXT9PsIKAtkHC3CUg',
    appId: '1:835195623873:macos:5e860b14d582d2f6163740',
    messagingSenderId: '835195623873',
    projectId: 'event-app-58dd0',
    storageBucket: 'event-app-58dd0.firebasestorage.app',
    iosClientId: 'YOUR_MACOS_CLIENT_ID',
    iosBundleId: 'com.example.eventApp',
  );
}
