import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';
import 'package:event_app/features/events/event_provider.dart';
import 'package:event_app/features/events/event_model.dart';
import 'package:event_app/services/cloud_firestore_service.dart';
import 'package:event_app/services/local_storage_service.dart';

@GenerateMocks([CloudFirestoreService, LocalStorageService, Box])
import 'event_provider_test.mocks.dart';

void main() {
  group('EventProvider Tests', () {
    late EventProvider eventProvider;
    late MockCloudFirestoreService mockFirestoreService;
    late MockLocalStorageService mockLocalStorageService;
    late MockBox<Event> mockEventBox;

    setUp(() {
      mockFirestoreService = MockCloudFirestoreService();
      mockLocalStorageService = MockLocalStorageService();
      mockEventBox = MockBox<Event>();
      eventProvider = EventProvider(
        firestoreService: mockFirestoreService,
        localStorageService: mockLocalStorageService,
      );
    });

    test('Initial state is empty', () {
      expect(eventProvider.events, isEmpty);
      expect(eventProvider.isLoading, false);
      expect(eventProvider.error, isNull);
    });

    test('Add event updates state and storage', () async {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
      );

      when(mockFirestoreService.addEvent(event))
          .thenAnswer((_) => Future.value(event));
      when(mockLocalStorageService.addEvent(event))
          .thenAnswer((_) => Future.value());

      await eventProvider.addEvent(event);

      expect(eventProvider.events.length, 1);
      expect(eventProvider.events.first, event);
      verify(mockFirestoreService.addEvent(event)).called(1);
      verify(mockLocalStorageService.addEvent(event)).called(1);
    });

    test('Update event updates state and storage', () async {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
      );

      final updatedEvent = event.copyWith(
        title: 'Updated Event',
        description: 'Updated Description',
      );

      eventProvider.events.add(event);
      when(mockFirestoreService.updateEvent(updatedEvent))
          .thenAnswer((_) => Future.value(updatedEvent));
      when(mockLocalStorageService.updateEvent(updatedEvent))
          .thenAnswer((_) => Future.value());

      await eventProvider.updateEvent(updatedEvent);

      expect(eventProvider.events.length, 1);
      expect(eventProvider.events.first.title, 'Updated Event');
      expect(eventProvider.events.first.description, 'Updated Description');
      verify(mockFirestoreService.updateEvent(updatedEvent)).called(1);
      verify(mockLocalStorageService.updateEvent(updatedEvent)).called(1);
    });

    test('Delete event removes from state and storage', () async {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
      );

      eventProvider.events.add(event);
      when(mockFirestoreService.deleteEvent(event.id))
          .thenAnswer((_) => Future.value());
      when(mockLocalStorageService.deleteEvent(event.id))
          .thenAnswer((_) => Future.value());

      await eventProvider.deleteEvent(event.id);

      expect(eventProvider.events, isEmpty);
      verify(mockFirestoreService.deleteEvent(event.id)).called(1);
      verify(mockLocalStorageService.deleteEvent(event.id)).called(1);
    });

    test('Load events from storage and Firestore', () async {
      final events = [
        Event(
          id: '1',
          title: 'Event 1',
          description: 'Description 1',
          date: DateTime(2024, 4, 22),
          location: 'Location 1',
          createdBy: 'user123',
        ),
        Event(
          id: '2',
          title: 'Event 2',
          description: 'Description 2',
          date: DateTime(2024, 4, 23),
          location: 'Location 2',
          createdBy: 'user123',
        ),
      ];

      when(mockFirestoreService.getEvents())
          .thenAnswer((_) => Future.value(events));
      when(mockLocalStorageService.getEvents())
          .thenAnswer((_) => Future.value(events));

      await eventProvider.loadEvents();

      expect(eventProvider.events.length, 2);
      expect(eventProvider.isLoading, false);
      expect(eventProvider.error, isNull);
      verify(mockFirestoreService.getEvents()).called(1);
      verify(mockLocalStorageService.getEvents()).called(1);
    });

    test('Handle error when loading events', () async {
      when(mockFirestoreService.getEvents())
          .thenThrow(Exception('Failed to load events'));

      await eventProvider.loadEvents();

      expect(eventProvider.events, isEmpty);
      expect(eventProvider.isLoading, false);
      expect(eventProvider.error, isNotNull);
      expect(eventProvider.error!.message, 'Failed to load events');
    });
  });
}
