import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:event_app/features/events/event_provider.dart';
import 'package:event_app/features/events/event_list_screen.dart';
import 'package:event_app/features/events/event_model.dart';
import 'package:event_app/core/app_constants.dart';

class MockEventProvider extends Mock implements EventProvider {}

class MockNavigatorObserver extends Mock implements NavigatorObserver {}

void main() {
  group('EventListScreen Widget Tests', () {
    late MockEventProvider mockEventProvider;
    late MockNavigatorObserver mockNavigatorObserver;
    late List<Event> mockEvents;

    setUp(() {
      mockEventProvider = MockEventProvider();
      mockNavigatorObserver = MockNavigatorObserver();
      mockEvents = [
        Event(
          id: '1',
          title: 'Birthday Party',
          description: 'A fun birthday celebration',
          date: DateTime.now().add(const Duration(days: 1)),
          location: 'Home',
          category: 'Birthday Party',
          userId: 'user123',
        ),
        Event(
          id: '2',
          title: 'Wedding Ceremony',
          description: 'A beautiful wedding',
          date: DateTime.now().add(const Duration(days: 7)),
          location: 'Beach Resort',
          category: 'Wedding Ceremony',
          userId: 'user123',
        ),
      ];
    });

    Widget createEventListScreen() {
      return MaterialApp(
        home: ChangeNotifierProvider<EventProvider>.value(
          value: mockEventProvider,
          child: const EventListScreen(),
        ),
        navigatorObservers: [mockNavigatorObserver],
      );
    }

    testWidgets('should display loading indicator when loading',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(true);
      when(mockEventProvider.events).thenReturn([]);

      await tester.pumpWidget(createEventListScreen());

      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });

    testWidgets('should display error message when there is an error',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn('Failed to load events');
      when(mockEventProvider.events).thenReturn([]);

      await tester.pumpWidget(createEventListScreen());

      expect(find.text('Failed to load events'), findsOneWidget);
    });

    testWidgets('should display empty state when there are no events',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn(null);
      when(mockEventProvider.events).thenReturn([]);

      await tester.pumpWidget(createEventListScreen());

      expect(find.text('No events yet'), findsOneWidget);
      expect(find.text('Tap the + button to add an event'), findsOneWidget);
    });

    testWidgets('should display list of events when available',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn(null);
      when(mockEventProvider.events).thenReturn(mockEvents);

      await tester.pumpWidget(createEventListScreen());

      expect(find.text('Birthday Party'), findsOneWidget);
      expect(find.text('Wedding Ceremony'), findsOneWidget);
      expect(find.text('Home'), findsOneWidget);
      expect(find.text('Beach Resort'), findsOneWidget);
    });

    testWidgets('should navigate to add event screen when FAB is pressed',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn(null);
      when(mockEventProvider.events).thenReturn([]);

      await tester.pumpWidget(createEventListScreen());
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      verify(mockNavigatorObserver.didPush(any, any)).called(1);
    });

    testWidgets('should navigate to event details when event card is tapped',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn(null);
      when(mockEventProvider.events).thenReturn(mockEvents);

      await tester.pumpWidget(createEventListScreen());
      await tester.tap(find.text('Birthday Party'));
      await tester.pumpAndSettle();

      verify(mockNavigatorObserver.didPush(any, any)).called(1);
    });

    testWidgets('should navigate to profile screen when profile icon is tapped',
        (WidgetTester tester) async {
      when(mockEventProvider.isLoading).thenReturn(false);
      when(mockEventProvider.error).thenReturn(null);
      when(mockEventProvider.events).thenReturn([]);

      await tester.pumpWidget(createEventListScreen());
      await tester.tap(find.byIcon(Icons.person));
      await tester.pumpAndSettle();

      verify(mockNavigatorObserver.didPush(any, any)).called(1);
    });
  });
}
