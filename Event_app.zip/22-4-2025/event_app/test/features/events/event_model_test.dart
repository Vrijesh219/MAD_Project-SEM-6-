import 'package:flutter_test/flutter_test.dart';
import 'package:event_app/features/events/event_model.dart';

void main() {
  group('Event Model Tests', () {
    test('Create Event with required fields', () {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
      );

      expect(event.id, '1');
      expect(event.title, 'Test Event');
      expect(event.description, 'Test Description');
      expect(event.date, DateTime(2024, 4, 22));
      expect(event.location, 'Test Location');
      expect(event.createdBy, 'user123');
    });

    test('Create Event with all fields', () {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
        imageUrl: 'https://example.com/image.jpg',
        attendees: ['user1', 'user2'],
        category: 'Conference',
        isPublic: true,
      );

      expect(event.imageUrl, 'https://example.com/image.jpg');
      expect(event.attendees, ['user1', 'user2']);
      expect(event.category, 'Conference');
      expect(event.isPublic, true);
    });

    test('copyWith updates correct fields', () {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
      );

      final updatedEvent = event.copyWith(
        title: 'Updated Event',
        description: 'Updated Description',
      );

      expect(updatedEvent.id, event.id);
      expect(updatedEvent.title, 'Updated Event');
      expect(updatedEvent.description, 'Updated Description');
      expect(updatedEvent.date, event.date);
      expect(updatedEvent.location, event.location);
      expect(updatedEvent.createdBy, event.createdBy);
    });

    test('toJson and fromJson work correctly', () {
      final event = Event(
        id: '1',
        title: 'Test Event',
        description: 'Test Description',
        date: DateTime(2024, 4, 22),
        location: 'Test Location',
        createdBy: 'user123',
        imageUrl: 'https://example.com/image.jpg',
        attendees: ['user1', 'user2'],
        category: 'Conference',
        isPublic: true,
      );

      final json = event.toJson();
      final fromJson = Event.fromJson(json);

      expect(fromJson.id, event.id);
      expect(fromJson.title, event.title);
      expect(fromJson.description, event.description);
      expect(fromJson.date.toIso8601String(), event.date.toIso8601String());
      expect(fromJson.location, event.location);
      expect(fromJson.createdBy, event.createdBy);
      expect(fromJson.imageUrl, event.imageUrl);
      expect(fromJson.attendees, event.attendees);
      expect(fromJson.category, event.category);
      expect(fromJson.isPublic, event.isPublic);
    });
  });
}
