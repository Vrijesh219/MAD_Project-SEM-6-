import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:hive/hive.dart';
import 'package:event_app/features/auth/auth_service.dart';
import 'package:event_app/models/user_model.dart';

@GenerateMocks([
  FirebaseAuth,
  GoogleSignIn,
  FacebookAuth,
  UserCredential,
  User,
  Box,
])
import 'auth_service_test.mocks.dart';

void main() {
  group('AuthService Tests', () {
    late AuthService authService;
    late MockFirebaseAuth mockFirebaseAuth;
    late MockGoogleSignIn mockGoogleSignIn;
    late MockFacebookAuth mockFacebookAuth;
    late MockBox<UserModel> mockUserBox;

    setUp(() {
      mockFirebaseAuth = MockFirebaseAuth();
      mockGoogleSignIn = MockGoogleSignIn();
      mockFacebookAuth = MockFacebookAuth();
      mockUserBox = MockBox<UserModel>();
      authService = AuthService(
        firebaseAuth: mockFirebaseAuth,
        googleSignIn: mockGoogleSignIn,
        facebookAuth: mockFacebookAuth,
        userBox: mockUserBox,
      );
    });

    test('Current user returns Firebase user', () {
      final mockUser = MockUser();
      when(mockFirebaseAuth.currentUser).thenReturn(mockUser);
      when(mockUser.uid).thenReturn('test-uid');
      when(mockUser.email).thenReturn('test@example.com');
      when(mockUser.displayName).thenReturn('Test User');

      final currentUser = authService.currentUser;

      expect(currentUser, isNotNull);
      expect(currentUser!.uid, 'test-uid');
      expect(currentUser.email, 'test@example.com');
      expect(currentUser.displayName, 'Test User');
    });

    test('Sign in with Google succeeds', () async {
      final mockGoogleSignInAccount = MockGoogleSignInAccount();
      final mockGoogleSignInAuthentication = MockGoogleSignInAuthentication();
      final mockUserCredential = MockUserCredential();
      final mockUser = MockUser();

      when(mockGoogleSignIn.signIn())
          .thenAnswer((_) => Future.value(mockGoogleSignInAccount));
      when(mockGoogleSignInAccount.authentication)
          .thenAnswer((_) => Future.value(mockGoogleSignInAuthentication));
      when(mockGoogleSignInAuthentication.accessToken)
          .thenReturn('mock-access-token');
      when(mockGoogleSignInAuthentication.idToken).thenReturn('mock-id-token');
      when(mockFirebaseAuth.signInWithCredential(any))
          .thenAnswer((_) => Future.value(mockUserCredential));
      when(mockUserCredential.user).thenReturn(mockUser);
      when(mockUser.uid).thenReturn('test-uid');
      when(mockUser.email).thenReturn('test@example.com');
      when(mockUser.displayName).thenReturn('Test User');

      final user = await authService.signInWithGoogle();

      expect(user, isNotNull);
      expect(user.uid, 'test-uid');
      expect(user.email, 'test@example.com');
      expect(user.displayName, 'Test User');
      verify(mockUserBox.put('currentUser', any)).called(1);
    });

    test('Sign in with Facebook succeeds', () async {
      final mockLoginResult = MockLoginResult();
      final mockAccessToken = MockAccessToken();
      final mockUserCredential = MockUserCredential();
      final mockUser = MockUser();

      when(mockFacebookAuth.login())
          .thenAnswer((_) => Future.value(mockLoginResult));
      when(mockLoginResult.status).thenReturn(LoginStatus.success);
      when(mockLoginResult.accessToken).thenReturn(mockAccessToken);
      when(mockAccessToken.token).thenReturn('mock-access-token');
      when(mockFirebaseAuth.signInWithCredential(any))
          .thenAnswer((_) => Future.value(mockUserCredential));
      when(mockUserCredential.user).thenReturn(mockUser);
      when(mockUser.uid).thenReturn('test-uid');
      when(mockUser.email).thenReturn('test@example.com');
      when(mockUser.displayName).thenReturn('Test User');

      final user = await authService.signInWithFacebook();

      expect(user, isNotNull);
      expect(user.uid, 'test-uid');
      expect(user.email, 'test@example.com');
      expect(user.displayName, 'Test User');
      verify(mockUserBox.put('currentUser', any)).called(1);
    });

    test('Sign out clears all auth states', () async {
      when(mockFirebaseAuth.signOut()).thenAnswer((_) => Future.value());
      when(mockGoogleSignIn.signOut()).thenAnswer((_) => Future.value());
      when(mockFacebookAuth.logOut()).thenAnswer((_) => Future.value());
      when(mockUserBox.delete('currentUser')).thenAnswer((_) => Future.value());

      await authService.signOut();

      verify(mockFirebaseAuth.signOut()).called(1);
      verify(mockGoogleSignIn.signOut()).called(1);
      verify(mockFacebookAuth.logOut()).called(1);
      verify(mockUserBox.delete('currentUser')).called(1);
    });

    test('Get user data returns stored user', () {
      final userModel = UserModel(
        uid: 'test-uid',
        email: 'test@example.com',
        displayName: 'Test User',
      );

      when(mockUserBox.get('currentUser')).thenReturn(userModel);

      final result = authService.getUserData();

      expect(result, isNotNull);
      expect(result!.uid, 'test-uid');
      expect(result.email, 'test@example.com');
      expect(result.displayName, 'Test User');
    });

    test('Sign in with Google throws on error', () {
      when(mockGoogleSignIn.signIn()).thenThrow(Exception('Sign in failed'));

      expect(
        () => authService.signInWithGoogle(),
        throwsA(isA<Exception>()),
      );
    });

    test('Sign in with Facebook throws on error', () {
      when(mockFacebookAuth.login()).thenThrow(Exception('Sign in failed'));

      expect(
        () => authService.signInWithFacebook(),
        throwsA(isA<Exception>()),
      );
    });
  });
}
