import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:event_app/features/auth/auth_service.dart';
import 'package:event_app/features/auth/login_screen.dart';
import 'package:event_app/core/app_constants.dart';

class MockAuthService extends Mock implements AuthService {}

class MockNavigatorObserver extends Mock implements NavigatorObserver {}

void main() {
  group('LoginScreen Widget Tests', () {
    late MockAuthService mockAuthService;
    late MockNavigatorObserver mockNavigatorObserver;

    setUp(() {
      mockAuthService = MockAuthService();
      mockNavigatorObserver = MockNavigatorObserver();
    });

    Widget createLoginScreen() {
      return MaterialApp(
        home: ChangeNotifierProvider<AuthService>.value(
          value: mockAuthService,
          child: const LoginScreen(),
        ),
        navigatorObservers: [mockNavigatorObserver],
      );
    }

    testWidgets('should display title and subtitle',
        (WidgetTester tester) async {
      await tester.pumpWidget(createLoginScreen());

      expect(find.text('EventEase'), findsOneWidget);
      expect(find.text('Manage your events with ease'), findsOneWidget);
    });

    testWidgets('should display Google and Facebook sign-in buttons',
        (WidgetTester tester) async {
      await tester.pumpWidget(createLoginScreen());

      expect(find.text('Continue with Google'), findsOneWidget);
      expect(find.text('Continue with Facebook'), findsOneWidget);
    });

    testWidgets('should call signInWithGoogle when Google button is pressed',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithGoogle()).thenAnswer((_) async => null);

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Google'));
      await tester.pumpAndSettle();

      verify(mockAuthService.signInWithGoogle()).called(1);
    });

    testWidgets(
        'should call signInWithFacebook when Facebook button is pressed',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithFacebook()).thenAnswer((_) async => null);

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Facebook'));
      await tester.pumpAndSettle();

      verify(mockAuthService.signInWithFacebook()).called(1);
    });

    testWidgets('should navigate to home screen on successful Google sign-in',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithGoogle()).thenAnswer((_) async => null);

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Google'));
      await tester.pumpAndSettle();

      verify(mockNavigatorObserver.didPush(any, any)).called(1);
    });

    testWidgets('should navigate to home screen on successful Facebook sign-in',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithFacebook()).thenAnswer((_) async => null);

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Facebook'));
      await tester.pumpAndSettle();

      verify(mockNavigatorObserver.didPush(any, any)).called(1);
    });

    testWidgets('should show error message on Google sign-in failure',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithGoogle())
          .thenThrow(Exception('Google Sign In Error'));

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Google'));
      await tester.pumpAndSettle();

      expect(
          find.text(
              'Error signing in with Google: Exception: Google Sign In Error'),
          findsOneWidget);
    });

    testWidgets('should show error message on Facebook sign-in failure',
        (WidgetTester tester) async {
      when(mockAuthService.signInWithFacebook())
          .thenThrow(Exception('Facebook Login Error'));

      await tester.pumpWidget(createLoginScreen());
      await tester.tap(find.text('Continue with Facebook'));
      await tester.pumpAndSettle();

      expect(
          find.text(
              'Error signing in with Facebook: Exception: Facebook Login Error'),
          findsOneWidget);
    });
  });
}
